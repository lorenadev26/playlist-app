import Foundation


struct YouTubeResponse: Codable {
    let items: [YouTubeVideoItem]
}

struct YouTubeVideoItem: Codable {
    let id: VideoID
    let snippet: Snippet
}

struct VideoID: Codable {
    let videoId: String?
}

struct Snippet: Codable {
    let title: String
}
