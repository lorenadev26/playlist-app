import Foundation

class SearchViewModel: ObservableObject {
    @Published var query: String = ""
    @Published var results: [MusicItem] = []
    @Published var recentQueries: [String] = []

    private let maxRecent = 10
    private let storageKey = "recent_searches"

    init() {
        loadRecentQueries()
    }

    func search() {
        guard !query.isEmpty else {
            results = []
            return
        }

        saveQuery(query)

        YouTubeAPIService.shared.search(query: query) { [weak self] items in
            DispatchQueue.main.async {
                self?.results = items
            }
        }
    }

    private func saveQuery(_ term: String) {
        var current = recentQueries
        current.removeAll(where: { $0.lowercased() == term.lowercased() }) // evitar duplicatas
        current.insert(term, at: 0)

        if current.count > maxRecent {
            current = Array(current.prefix(maxRecent))
        }

        recentQueries = current
        UserDefaults.standard.set(current, forKey: storageKey)
    }

    private func loadRecentQueries() {
        recentQueries = UserDefaults.standard.stringArray(forKey: storageKey) ?? []
    }
}
