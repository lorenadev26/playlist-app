import SwiftUI

struct ContentView: View {
    @State private var searchText = ""
    @State private var isSearchActive = false
    @State private var showPlaylist = false
    @State private var showBusca = false
    @State private var showCriar = false

    let menuItems: [Menu] = [
        Menu(title: "Buscar", icon: "magnifyingglass", destination: AnyView(SearchView())),
        Menu(title: "Biblioteca", icon: "folder.fill", destination: AnyView(PlaylistView())),
        Menu(title: "Criar", icon: "plus.circle.fill", destination: AnyView(CriarView()))
    ]
    
    var body: some View {
        
        NavigationView {
            Form{
                ForEach(menuItems) { item in
                    NavigationLink(destination: item.destination) {
                        HStack {
                            Image(systemName: item.icon)
                                .resizable()
                                .frame(width: 40, height: 40)
                            VStack(alignment: .leading) {
                                Text(item.title)
                            }
                        }
                    }
                }
            }
            .navigationTitle("PlayListApp")
            
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}
