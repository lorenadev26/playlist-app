//
//  playlistApp.swift
//  playlist
//
//  Created by Virtues25 on 26/06/25.
//

import SwiftUI

@main
struct playlistApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
