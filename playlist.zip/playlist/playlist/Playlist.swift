import SwiftUI

struct PlaylistView: View{
    var body: some View{
        Text("Tela de playlist")
    }
}
