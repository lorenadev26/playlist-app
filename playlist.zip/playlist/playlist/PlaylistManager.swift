import Foundation

class PlaylistManager {
    static let shared = PlaylistManager()
    private let key = "playlists"

    private init() {}

    func loadPlaylists() -> [Playlist] {
        if let data = UserDefaults.standard.data(forKey: key),
           let decoded = try? JSONDecoder().decode([Playlist].self, from: data) {
            return decoded
        }
        return []
    }

    func savePlaylists(_ playlists: [Playlist]) {
        if let data = try? JSONEncoder().encode(playlists) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    func save(music: MusicItem, toPlaylistNamed name: String = "Minha Playlist") {
        var playlists = loadPlaylists()
        if let index = playlists.firstIndex(where: { $0.name == name }) {
            playlists[index].musics.append(music)
        } else {
            playlists.append(Playlist(name: name, musics: [music]))
        }
        savePlaylists(playlists)
    }
}
