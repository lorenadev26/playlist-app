import Foundation

class YouTubeAPIService {
    static let shared = YouTubeAPIService()
    
    private let apiKey = "AIzaSyBeMHGCZdCxZl4t4KBm6SXrHDXFVr-1HLg" // Substitua aqui

    private init() {}

    func search(query: String, completion: @escaping ([MusicItem]) -> Void) {
        let encodedQuery = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let urlString = "https://www.googleapis.com/youtube/v3/search?part=snippet&q=\(encodedQuery)&type=video&maxResults=10&key=\(apiKey)"

        guard let url = URL(string: urlString) else {
            completion([])
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data,
                  let result = try? JSONDecoder().decode(YouTubeResponse.self, from: data) else {
                DispatchQueue.main.async { completion([]) }
                return
            }

            let items = result.items.compactMap { item -> MusicItem? in
                guard let videoId = item.id.videoId else { return nil }
                return MusicItem(
                    title: item.snippet.title,
                    videoURL: "https://www.youtube.com/watch?v=\(videoId)",
                    videoId: videoId
                )
            }

            DispatchQueue.main.async {
                completion(items)
            }

        }.resume()
    }
}
