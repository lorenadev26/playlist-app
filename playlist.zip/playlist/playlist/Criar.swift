import SwiftUI

struct CriarView: View {
    var body: some View {
        Text("Criar ou gerenciar playlists")
    }
}
