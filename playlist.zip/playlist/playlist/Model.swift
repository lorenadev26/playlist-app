import Foundation
import SwiftUI

struct MusicItem: Identifiable, Codable {
    let id = UUID()
    let title: String
    let videoURL: String
    let videoId: String
}

struct Playlist: Identifiable, Codable {
    var id = UUID()
    var name: String
    var musics: [MusicItem]
}

struct Menu: Identifiable{
    let id = UUID()
    let title: String
    let icon: String
    let destination: AnyView
}


//o Model é um molde dos dados que vai ser utilizado
