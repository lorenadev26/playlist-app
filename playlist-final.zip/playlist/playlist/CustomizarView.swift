import SwiftUI

struct CustomizarView: View {
    @AppStorage("darkModeEnabled") private var darkModeEnabled: Bool = false
    @AppStorage("appFontName")    private var fontName: String = "Sistema"
    @State private var showingFontPicker = false
    
    @Environment(\.colorScheme) var colorScheme
    @AppStorage("iconColorHex") var iconColorHex: String = "#000000"
    @AppStorage("textColorHex") var textColorHex: String = "#000000"


    private let colorOptions: [String] = [
        "#000000", "#FF9500", "#FF2D55", "#007AFF", "#34C759", "#AF52DE", "#FFCC00"
    ]

    private func colorFromHex(_ hex: String) -> Color {
        Color(UIColor(hex: hex))
    }

    
    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                // MARK: – Cartão Modo Escuro
                Toggle(isOn: $darkModeEnabled) {
                    Text("Modo escuro")
                        .fontWeight(.bold)
                        .foregroundColor(dynamicColor(from: textColorHex, fallbackDark: .white, fallbackLight: .black, colorScheme: colorScheme))
                }
                .padding()
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .shadow(radius: 2)
                
                // MARK: – Linha de Fonte
                HStack {
                    Text("Fonte")
                        .fontWeight(.bold)
                        .foregroundColor(dynamicColor(from: textColorHex, fallbackDark: .white, fallbackLight: .black, colorScheme: colorScheme))
                    Spacer()
                    Button("Alterar") {
                        showingFontPicker = true
                    }
                }
                .padding()
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .shadow(radius: 2)
                .sheet(isPresented: $showingFontPicker) {
                    FontPickerView(selectedFont: $fontName)
                }
                
                // MARK: – Cor dos Ícones
                VStack(alignment: .leading, spacing: 8) {
                    Text("Cor dos ícones")
                        .fontWeight(.bold)
                        .foregroundColor(dynamicColor(from: textColorHex, fallbackDark: .white, fallbackLight: .black, colorScheme: colorScheme))

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(colorOptions, id: \.self) { hex in
                                Circle()
                                    .fill(colorFromHex(hex))
                                    .frame(width: 36, height: 36)
                                    .overlay(
                                        Circle()
                                            .stroke(lineWidth: iconColorHex == hex ? 3 : 0)
                                            .foregroundColor(.primary)
                                    )
                                    .onTapGesture {
                                        iconColorHex = hex
                                    }
                            }
                        }
                        .padding()
                    }
                }
                .padding()
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .shadow(radius: 2)


                // MARK: – Cor dos Textos
                VStack(alignment: .leading, spacing: 8) {
                    Text("Cor dos textos")
                        .fontWeight(.bold)
                        .foregroundColor(dynamicColor(from: textColorHex, fallbackDark: .white, fallbackLight: .black, colorScheme: colorScheme))

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(colorOptions, id: \.self) { hex in
                                Circle()
                                    .fill(colorFromHex(hex))
                                    .frame(width: 36, height: 36)
                                    .overlay(
                                        Circle()
                                            .stroke(lineWidth: textColorHex == hex ? 3 : 0)
                                            .foregroundColor(.primary)
                                    )
                                    .onTapGesture {
                                        textColorHex = hex
                                    }
                            }
                        }
                        .padding()
                    }
                }
                .padding()
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .shadow(radius: 2)

                
                Button(action: resetDefaults) {
                    Label("Restaurar Padrão", systemImage: "arrow.counterclockwise")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(.systemRed).opacity(0.1))
                        .foregroundColor(.red)
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
                .padding(.top, 16)
            }
        }
    }
    
    private func resetDefaults() {
        darkModeEnabled = false
        fontName = "Sistema"
        iconColorHex = "#000000"
        textColorHex = "#000000"
        // volta ao ícone principal
        UIApplication.shared.setAlternateIconName(nil) { error in
            if let err = error {
                print("Erro ao resetar ícone: \(err)")
            }
        }
    }
    
    func dynamicColor(from hex: String, fallbackDark: Color, fallbackLight: Color, colorScheme: ColorScheme) -> Color {
        if hex == "#000000" || hex.isEmpty {
            return colorScheme == .dark ? fallbackDark : fallbackLight
        } else {
            return Color(UIColor(hex: hex))
        }
    }
    
}


