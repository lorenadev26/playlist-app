import SwiftUI

struct PlaylistView: View {
    @ObservedObject private var playlistManager = PlaylistManager.shared
    @Environment(\.colorScheme) var colorScheme
    @AppStorage("textColorHex") var textColorHex: String = "#000000"

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            if playlistManager.playlists.isEmpty {
                Text("Nenhuma playlist criada ainda.")
                    .foregroundColor(.gray)
                    .padding()
            } else {
                List {
                    ForEach(playlistManager.playlists) { playlist in
                        NavigationLink(destination: PlaylistDetailView(playlist: playlist)) {
                            HStack {
                                Image(systemName: "music.note.list")
                                Text(playlist.name)
                                    .foregroundColor(dynamicColor(from: textColorHex, fallbackDark: .white, fallbackLight: .black, colorScheme: colorScheme))
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle("Biblioteca")
    }

    private func dynamicColor(from hex: String, fallbackDark: Color, fallbackLight: Color, colorScheme: ColorScheme) -> Color {
        if hex == "#000000" || hex.isEmpty {
            return colorScheme == .dark ? fallbackDark : fallbackLight
        } else {
            return Color(UIColor(hex: hex))
        }
    }
}
