import SwiftUI

struct ContentView: View {
    @State private var searchText = ""
    @State private var isSearchActive = false
    @State private var showPlaylist = false
    @State private var showBusca = false
    @State private var showCriar = false
    
    @Environment(\.colorScheme) var colorScheme
    @AppStorage("iconColorHex") var iconColorHex: String = "#000000"
    @AppStorage("textColorHex") var textColorHex: String = "#000000"



    let menuItems: [Menu] = [
        Menu(title: "Buscar", icon: "magnifyingglass", destination: AnyView(SearchView())),
        Menu(title: "Biblioteca", icon: "folder.fill", destination: AnyView(PlaylistView())),
        Menu(title: "Criar", icon: "plus.circle.fill", destination: AnyView(CriarView())),
        Menu(title: "Personalize seu app", icon: "paintbrush", destination: AnyView(CustomizarView()))
    ]
    
    var body: some View {
        
        NavigationView {
            Form{
                ForEach(menuItems) { item in
                    NavigationLink(destination: item.destination) {
                        HStack {
                            Image(systemName: item.icon)
                                .resizable()
                                .frame(width: 40, height: 40)
                                .foregroundColor(dynamicColor(from: iconColorHex, fallbackDark: .white, fallbackLight: .black, colorScheme: colorScheme))
                            VStack(alignment: .leading) {
                                Text(item.title)
                                    .foregroundColor(dynamicColor(from: textColorHex, fallbackDark: .white, fallbackLight: .black, colorScheme: colorScheme))
                            }
                        }
                    }
                }
            }
            .navigationTitle("Playlist App")
            
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
    
    func dynamicColor(from hex: String, fallbackDark: Color, fallbackLight: Color, colorScheme: ColorScheme) -> Color {
        if hex == "#000000" || hex.isEmpty {
            return colorScheme == .dark ? fallbackDark : fallbackLight
        } else {
            return Color(UIColor(hex: hex))
        }
    }
    
}
