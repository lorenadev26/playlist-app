import Foundation
import SwiftUI
import UIKit

struct MusicItem: Identifiable, Codable {
    let id = UUID()
    let title: String
    let videoURL: String
    let videoId: String
}

struct Playlist: Identifiable, Codable {
    var id = UUID()
    var name: String
    var musics: [MusicItem]
}

struct Menu: Identifiable{
    let id = UUID()
    let title: String
    let icon: String
    let destination: AnyView
}


struct PlaylistDetailView: View {
    let playlist: Playlist
    @Environment(\.colorScheme) var colorScheme
    @AppStorage("textColorHex") var textColorHex: String = "#000000"

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if playlist.musics.isEmpty {
                Text("Nenhuma música nesta playlist.")
                    .foregroundColor(.gray)
                    .padding()
            } else {
                List {
                    ForEach(playlist.musics) { music in
                        Text(music.title)
                            .foregroundColor(dynamicColor(from: textColorHex, fallbackDark: .white, fallbackLight: .black, colorScheme: colorScheme))
                    }
                }
            }
        }
        .navigationTitle(playlist.name)
    }

    private func dynamicColor(from hex: String, fallbackDark: Color, fallbackLight: Color, colorScheme: ColorScheme) -> Color {
        if hex == "#000000" || hex.isEmpty {
            return colorScheme == .dark ? fallbackDark : fallbackLight
        } else {
            return Color(UIColor(hex: hex))
        }
    }
}


extension UIColor {
    convenience init(hex: String) {
        var hex = hex
        if hex.hasPrefix("#") { hex.removeFirst() }

        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)

        let r = CGFloat((int >> 16) & 0xFF) / 255
        let g = CGFloat((int >> 8) & 0xFF) / 255
        let b = CGFloat(int & 0xFF) / 255

        self.init(red: r, green: g, blue: b, alpha: 1)
    }
}

struct FontPickerView: View {
    @Binding var selectedFont: String
    @Environment(\.presentationMode) private var presentationMode

    /// Lista de famílias de fontes no sistema
    private let fonts: [String] = UIFont
        .familyNames
        .sorted()

    var body: some View {
        NavigationView {
            List(fonts, id: \.self) { font in
                Button {
                    selectedFont = font
                    presentationMode.wrappedValue.dismiss()
                } label: {
                    Text(font)
                        .font(.custom(font, size: 18))
                        .foregroundColor(.primary)
                }
            }
            .navigationTitle("Escolha a Fonte")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            }
        }
    }
    
    func dynamicColor(from hex: String, fallbackDark: Color, fallbackLight: Color, colorScheme: ColorScheme) -> Color {
        if hex == "#000000" || hex.isEmpty {
            return colorScheme == .dark ? fallbackDark : fallbackLight
        } else {
            return Color(UIColor(hex: hex))
        }
    }

    
}

struct SelectPlaylistView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject private var playlistManager = PlaylistManager.shared
    let musics: [MusicItem]

    var body: some View {
        NavigationView {
            List {
                ForEach(playlistManager.playlists) { playlist in
                    Button {
                        adicionar(musics, para: playlist)
                    } label: {
                        Text(playlist.name)
                    }
                }
            }
            .navigationTitle("Selecionar Playlist")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            }
        }
    }

    private func adicionar(_ musicas: [MusicItem], para playlist: Playlist) {
        if let index = playlistManager.playlists.firstIndex(where: { $0.id == playlist.id }) {
            var atualizada = playlistManager.playlists[index]

            for m in musicas where !atualizada.musics.contains(where: { $0.id == m.id }) {
                atualizada.musics.append(m)
            }

            playlistManager.playlists[index] = atualizada
            playlistManager.persistPlaylistsExternamente() // Novo método que você pode adicionar
            presentationMode.wrappedValue.dismiss()
        }
    }
}


//o Model é um molde dos dados que vai ser utilizado
