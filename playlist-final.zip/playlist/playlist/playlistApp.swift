import SwiftUI

@main
struct playlistApp: App {
    @State private var isSplashActive = true
    @AppStorage("darkModeEnabled") private var darkModeEnabled: Bool = false
    @AppStorage("appFontName")    private var fontName: String = "Sistema"
    @Environment(\.colorScheme) var colorScheme
    @AppStorage("iconColorHex") var iconColorHex: String = "#000000"
    @AppStorage("textColorHex") var textColorHex: String = "#000000"


    var body: some Scene {
        WindowGroup {
            if isSplashActive {
                SplashView()
                    .onAppear {
                        // Simula um delay de 2 segundos antes de ir para a tela principal
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            withAnimation {
                                isSplashActive = false
                            }
                        }
                    }
            } else {
                ContentView()
                    .preferredColorScheme(darkModeEnabled ? .dark : .light)
                    .font(fontModifier(for: fontName))
            }
        }       
    }
    private func fontModifier(for name: String) -> Font {
            if name == "Sistema" {
                return .body
            } else {
                return .custom(name, size: 16)
            }
        }
}

