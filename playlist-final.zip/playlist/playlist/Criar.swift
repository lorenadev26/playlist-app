import SwiftUI

struct CriarView: View {
    @ObservedObject var playlistManager = PlaylistManager.shared
    @Environment(\.colorScheme) var colorScheme
    @AppStorage("iconColorHex") var iconColorHex: String = "#000000"
    @AppStorage("textColorHex") var textColorHex: String = "#000000"

    @State private var selectedMusics: Set<UUID> = []
    @State private var showPlaylistAlert = false
    @State private var playlistName = ""
    @State private var isCreatingNewPlaylist = true
    @State private var showSelectExisting = false

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            GroupBox(label:
                Label("Selecione Músicas", systemImage: "checklist")
                    .foregroundColor(dynamicColor(from: textColorHex, fallbackDark: .white, fallbackLight: .black, colorScheme: colorScheme))
            ) {
                if playlistManager.savedMusics.isEmpty {
                    Text("Nenhuma música salva ainda.")
                        .foregroundColor(.gray)
                        .padding(.top, 8)
                } else {
                    ForEach(playlistManager.savedMusics) { music in
                        Button {
                            toggleSelection(music.id)
                        } label: {
                            HStack {
                                Image(systemName: selectedMusics.contains(music.id) ? "checkmark.circle.fill" : "circle")
                                Text(music.title)
                                    .foregroundColor(dynamicColor(from: textColorHex, fallbackDark: .white, fallbackLight: .black, colorScheme: colorScheme))
                            }
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
            }
            .padding()

            // Botões: criar nova ou adicionar a existente
            HStack {
                Button {
                    isCreatingNewPlaylist = true
                    showPlaylistAlert = true
                } label: {
                    Label("Nova Playlist", systemImage: "plus.circle")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue.opacity(0.1))
                        .foregroundColor(.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }

                Button {
                    isCreatingNewPlaylist = false
                    showSelectExisting = true
                } label: {
                    Label("Adicionar a Existente", systemImage: "folder")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green.opacity(0.1))
                        .foregroundColor(.green)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
            }
            .padding(.horizontal)

            Spacer()
        }
        .navigationTitle("Criar Playlist")
        .alert("Nome da Playlist", isPresented: $showPlaylistAlert) {
            TextField("Minha Playlist", text: $playlistName)
            Button("Salvar", action: criarNovaPlaylist)
            Button("Cancelar", role: .cancel) { }
        } message: {
            Text("Escolha um nome para a nova playlist.")
        }
        .sheet(isPresented: $showSelectExisting) {
            SelectPlaylistView(musics: musicsSelecionadas)
        }
    }

    private func toggleSelection(_ id: UUID) {
        if selectedMusics.contains(id) {
            selectedMusics.remove(id)
        } else {
            selectedMusics.insert(id)
        }
    }

    private var musicsSelecionadas: [MusicItem] {
        playlistManager.savedMusics.filter { selectedMusics.contains($0.id) }
    }

    private func criarNovaPlaylist() {
        guard !playlistName.trimmingCharacters(in: .whitespaces).isEmpty,
              !musicsSelecionadas.isEmpty else { return }

        let nova = Playlist(name: playlistName, musics: musicsSelecionadas)
        playlistManager.savePlaylist(nova)
        playlistName = ""
        selectedMusics = []
    }

    private func dynamicColor(from hex: String, fallbackDark: Color, fallbackLight: Color, colorScheme: ColorScheme) -> Color {
        if hex == "#000000" || hex.isEmpty {
            return colorScheme == .dark ? fallbackDark : fallbackLight
        } else {
            return Color(UIColor(hex: hex))
        }
    }
}
