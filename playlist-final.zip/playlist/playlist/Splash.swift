import SwiftUI

struct SplashView: View{
    
    var body: some View{
        ZStack{
            Color.white.ignoresSafeArea()
            VStack{
                Image("Logo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 450, height: 450)
            }
        }
    }
}
