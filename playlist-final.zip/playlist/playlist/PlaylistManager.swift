import Foundation
import SwiftUI

class PlaylistManager: ObservableObject {
    static let shared = PlaylistManager()

    @Published private(set) var savedMusics: [MusicItem] = []
    @Published var playlists: [Playlist] = []

    private let musicsKey = "saved_musics"
    private let playlistsKey = "saved_playlists"

    init() {
        load()
    }

    func save(music: MusicItem) {
        if !savedMusics.contains(where: { $0.videoId == music.videoId }) {
            savedMusics.append(music)
            persistMusics()
        }
    }

    func clearSavedMusics() {
        savedMusics = []
        persistMusics()
    }

    func savePlaylist(_ playlist: Playlist) {
        playlists.append(playlist)
        persistPlaylists()
    }

    private func persistMusics() {
        if let data = try? JSONEncoder().encode(savedMusics) {
            UserDefaults.standard.set(data, forKey: musicsKey)
        }
    }

    private func persistPlaylists() {
        if let data = try? JSONEncoder().encode(playlists) {
            UserDefaults.standard.set(data, forKey: playlistsKey)
        }
    }

    private func load() {
        if let data = UserDefaults.standard.data(forKey: musicsKey),
           let items = try? JSONDecoder().decode([MusicItem].self, from: data) {
            savedMusics = items
        }

        if let data = UserDefaults.standard.data(forKey: playlistsKey),
           let saved = try? JSONDecoder().decode([Playlist].self, from: data) {
            playlists = saved
        }
    }
    
    func persistPlaylistsExternamente() {
        if let data = try? JSONEncoder().encode(playlists) {
            UserDefaults.standard.set(data, forKey: playlistsKey)
        }
    }

}
