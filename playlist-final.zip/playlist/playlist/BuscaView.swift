import SwiftUI

struct SearchView: View {
    @StateObject private var viewModel = SearchViewModel()
    @State private var showSaveAlert = false


    var body: some View {
        VStack(spacing: 12) {
            // 🔍 Barra de busca
            HStack {
                Image(systemName: "magnifyingglass")
                TextField("Buscar no YouTube...", text: $viewModel.query)
                    .onSubmit { viewModel.search() }
            }
            .padding()
            .background(Color(.systemGray6))
            .cornerRadius(10)
            .padding(.horizontal)
            .padding(.top)

            // 🕘 Recentes
            if !viewModel.recentQueries.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(viewModel.recentQueries, id: \.self) { term in
                            Button {
                                viewModel.query = term
                                viewModel.search()
                            } label: {
                                Text(term)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 6)
                                    .background(Color(.systemGray5))
                                    .cornerRadius(8)
                            }
                        }
                    }
                    .padding(.horizontal)
                }
            }

            // 📋 Resultados
            if viewModel.results.isEmpty {
                Spacer()
                Text("Nenhum resultado ainda.")
                    .foregroundColor(.gray)
                Spacer()
            } else {
                ScrollView {
                    LazyVStack(spacing: 12) {
                        ForEach(viewModel.results) { item in
                            HStack(alignment: .top) {
                                // Thumbnail
                                AsyncImage(url: URL(string: "https://img.youtube.com/vi/\(item.videoId)/mqdefault.jpg")) { image in
                                    image
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .frame(width: 100, height: 56)
                                        .clipped()
                                } placeholder: {
                                    ProgressView()
                                        .frame(width: 100, height: 56)
                                }

                                VStack(alignment: .leading, spacing: 4) {
                                    Text(item.title)
                                        .font(.headline)

                                    HStack {
                                        Button("Abrir no YouTube") {
                                            if let url = URL(string: item.videoURL) {
                                                UIApplication.shared.open(url)
                                            }
                                        }
                                        .font(.caption)
                                        .foregroundColor(.blue)
                                        .buttonStyle(.plain)

                                        Spacer()

                                        Button("Salvar") {
                                            PlaylistManager.shared.save(music: item)
                                            showSaveAlert = true
                                        }
                                        .font(.caption)
                                        .foregroundColor(.green)
                                        .buttonStyle(.plain)
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                    .padding(.top)
                }
            }
        }
        .navigationTitle("Buscar Músicas")
        .alert("Salvo com sucesso", isPresented: $showSaveAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("O vídeo foi adicionado para criação de playlist.")
        }
    }
}

